function showSection(id) {
    document.querySelectorAll("section").forEach(sec => sec.classList.remove("active"));
    const target = document.getElementById(id);
    if (target) target.classList.add("active");
    updateUI();
}

async function updateUI() {
    try {
        // Comme app.js est dans le dossier /js, api.php est juste à côté
        const response = await fetch('js/api.php?action=get_all_data');
        if (!response.ok) throw new Error("Erreur serveur");
        
        const data = await response.json();
        const drones = data.drones || [];

        // 1. DASHBOARD
        const free = drones.filter(d => d.status.toLowerCase() === 'libre');
        const busy = drones.filter(d => d.status.toLowerCase() === 'mission');

        const elFree = document.getElementById('countFree');
        const elBusy = document.getElementById('countBusy');
        if(elFree) elFree.innerText = free.length;
        if(elBusy) elBusy.innerText = busy.length;

        // 2. TABLEAU
        const tableBody = document.getElementById('droneTableBody');
        if (tableBody) {
            tableBody.innerHTML = ""; 
            drones.forEach(d => {
                tableBody.innerHTML += `
                    <tr>
                        <td>${d.nom}</td>
                        <td>${d.type_cap}</td>
                        <td style="color: ${d.status.toLowerCase() === 'libre' ? 'green' : 'orange'}">${d.status}</td>
                    </tr>`;
            });
        }

        // 3. SELECT
        const select = document.getElementById('m_drone_select');
        if (select) {
            select.innerHTML = '<option value="">-- Choisir un drone libre --</option>';
            free.forEach(d => {
                select.innerHTML += `<option value="${d.id}">${d.nom}</option>`;
            });
        }
    } catch (e) {
        console.error("Erreur de mise à jour UI : ", e.message);
    }
}

async function submitMission() {
    const droneId = document.getElementById('m_drone_select').value;
    if(!droneId) return alert("Sélectionnez un drone");

    const formData = new FormData();
    formData.append('drone_id', droneId);
    formData.append('nom_mission', document.getElementById('m_nom').value);
    formData.append('date_mission', document.getElementById('m_date').value);

    try {
        const res = await fetch('js/api.php?action=save_mission', { method: 'POST', body: formData });
        const result = await res.json();
        
        document.getElementById('missionStatusMsg').innerText = result.message;
        if(result.success) {
            document.getElementById('missionForm').reset();
            updateUI();
        }
    } catch (e) {
        console.error("Erreur d'envoi :", e);
    }
}

window.onload = updateUI;