// ═══════════════════════════════════════════════
//  data.js — API calls + utilitaires partagés
// ═══════════════════════════════════════════════

const API = 'api/api.php';

// ── Appel API générique ───────────────────────────
async function apiGet(action, params = {}) {
  const qs = new URLSearchParams({ action, ...params }).toString();
  const res = await fetch(`${API}?${qs}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiPost(action, body = {}) {
  const res = await fetch(`${API}?action=${action}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.message || `HTTP ${res.status}`);
  }
  return res.json();
}

// ── Auth ──────────────────────────────────────────
function getCurrentUser() {
  const u = sessionStorage.getItem('bd_user');
  return u ? JSON.parse(u) : null;
}

function requireRole(role) {
  const user = getCurrentUser();
  if (!user) { window.location.href = 'index.html'; return null; }
  if (user.role !== role) { window.location.href = user.role === 'admin' ? 'admin.html' : 'user.html'; return null; }
  return user;
}

function logout() {
  sessionStorage.removeItem('bd_user');
  window.location.href = 'index.html';
}

// Initialisé au chargement (plus de localStorage nécessaire)

// ── Helpers UI ────────────────────────────────────
function droneEmoji(type) {
  return { 'RGB':'📷', 'Multispectral':'🌿', 'Thermique':'🌡️', 'LiDAR':'📡', 'Pulvérisation':'💧' }[type] || '🚁';
}

function statusLabel(s) {
  return { 'libre':'Libre', 'mission':'En mission', 'maintenance':'Maintenance',
           'attente':'En attente', 'approuve':'Approuvé', 'rejete':'Rejeté' }[s] || s;
}

function statusBadge(s) {
  const cls = { 'libre':'badge-green', 'mission':'badge-orange', 'maintenance':'badge-blue',
                'attente':'badge-purple', 'approuve':'badge-green', 'rejete':'badge-red' }[s] || 'badge-purple';
  return `<span class="status-badge ${cls}">${statusLabel(s)}</span>`;
}

function emptyState(msg) {
  return `<div class="empty-state"><div style="font-size:2rem;margin-bottom:8px">📭</div><p>${msg}</p></div>`;
}

function showAlert(elId, msg, type) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = msg;
  el.className = `form-alert alert-${type}`;
  el.style.display = 'block';
  setTimeout(() => { el.style.display = 'none'; }, 5000);
}

function todayStr() {
  return new Date().toLocaleDateString('fr-FR');
}

// ── Navigation ────────────────────────────────────
const TITLES = {
  dashboard: 'Vue d\'ensemble', drones: 'Drones disponibles',
  reserver: 'Réserver un drone', deposer: 'Déposer un drone',
  mesDemandes: 'Mes demandes', tousLesDrones: 'Tous les drones',
  reservations: 'Demandes de réservation', depots: 'Dépôts de drones',
};

function showSection(id) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelector(`[data-s="${id}"]`)?.classList.add('active');
  document.getElementById('topbarTitle').textContent = TITLES[id] || id;
  document.getElementById('sidebar').classList.remove('open');
  renderSection(id);
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

function switchTab(id, btn) {
  const parent = btn.closest('.section');
  parent.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  parent.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById(id).classList.add('active');
}


