// login.js

document.getElementById('email').addEventListener('input', previewRole);
document.getElementById('password').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
document.getElementById('email').addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('password').focus(); });

function previewRole() {
  const email = document.getElementById('email').value.trim();
  const user  = USERS.find(u => u.email === email);
  const ind   = document.getElementById('roleIndicator');
  if (user) {
    ind.className = `role-indicator show ${user.role}`;
    ind.innerHTML = user.role === 'admin'
      ? '🛡️ Redirection vers l\'espace <strong>Administrateur</strong>'
      : '👤 Redirection vers l\'espace <strong>Utilisateur</strong>';
  } else {
    ind.className = 'role-indicator';
    ind.innerHTML = '';
  }
}

function fillDemo(type) {
  document.getElementById('email').value    = type === 'admin' ? 'admin@bicod.sn' : 'user@bicod.sn';
  document.getElementById('password').value = type === 'admin' ? 'admin' : '1234';
  previewRole();
}

async function doLogin() {
  const email   = document.getElementById('email').value.trim();
  const pwd     = document.getElementById('password').value;
  const alertEl = document.getElementById('alertBox');
  const btn     = document.querySelector('.btn-primary');

  if (!email || !pwd) {
    alertEl.textContent = 'Veuillez remplir tous les champs.';
    alertEl.style.display = 'block';
    return;
  }

  btn.textContent = 'Connexion...';
  btn.disabled = true;

  try {
    const data = await apiPost('login', { email, password: pwd });
    alertEl.style.display = 'none';
    sessionStorage.setItem('bd_user', JSON.stringify(data.user));
    window.location.href = data.user.role === 'admin' ? 'admin.html' : 'user.html';
  } catch (e) {
    alertEl.textContent = e.message || 'Email ou mot de passe incorrect.';
    alertEl.style.display = 'block';
    btn.textContent = 'Se connecter';
    btn.disabled = false;
  }
}
